import os
import sys

# Ensure the project root is in the path when this file is run directly.
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from app.database import get_db_connection, init_db
from app.config import settings


def seed_database():
    """Recreate the configured development/test database with demo identities.

    WARNING: this function deletes the database file named by DATABASE_URL
    before recreating it. Only run it against a disposable database or after
    taking a backup.
    """
    db_file = settings.DATABASE_URL.replace("sqlite:///", "")

    # Start fresh for development/testing. This is destructive by design.
    if os.path.exists(db_file):
        os.remove(db_file)

    init_db()
    conn = get_db_connection()
    try:
        # Primary usernames are the canonical identities. Legacy usernames are
        # login aliases handled in app/main.py; they are not separate DB rows.
        users = [
            (101, "balanilavan", "hash_balanilavan123", "user"),
            (102, "kapilesh", "hash_kapilesh123", "user"),
            (103, "sakthivel", "hash_sakthivel123", "user"),
            (104, "chinmayanand", "hash_chinmayanand123", "admin"),
        ]
        conn.executemany(
            "INSERT INTO users (id, username, password_hash, role) VALUES (?, ?, ?, ?)",
            users,
        )

        # Object IDs are independent of user IDs. owner_id references users.id.
        # Resource 103 belongs to Chinmayanand (user 104); resource 104 belongs
        # to Sakthivel (user 103). The 201 -> 202/203 relationship is preserved
        # for nested BOLA tests; tests can attach object 102 to folder 201.
        objects = [
            (101, "document", 101, "B.V. Balanilavan's Secret Note", None),
            (102, "document", 102, "Kapilesh N's Financial Record", None),
            (103, "document", 104, "Agnihotram Chinmayanand's Admin Log", None),
            (104, "document", 103, "Sakthivel B's Research Note", None),
            (201, "folder", 101, "B.V. Balanilavan's Projects", None),
            (202, "document", 101, "Project Alpha Plan", 201),
            (203, "document", 101, "Project Beta Plan", 201),
        ]
        conn.executemany(
            """INSERT INTO objects
               (id, object_type, owner_id, name, parent_id)
               VALUES (?, ?, ?, ?, ?)""",
            objects,
        )
        conn.commit()
    finally:
        conn.close()


if __name__ == "__main__":
    seed_database()
    print("Database successfully seeded with Balanilavan, Kapilesh, Sakthivel, and Chinmayanand.")
