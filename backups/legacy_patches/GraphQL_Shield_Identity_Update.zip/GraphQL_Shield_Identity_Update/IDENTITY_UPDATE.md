# GraphQL-Shield identity update

## Final account mapping

| User ID | Canonical username | Legacy login alias | Display name | Role | Seed password |
|---:|---|---|---|---|---|
| 101 | `balanilavan` | `bala` | B.V. Balanilavan | USER | `balanilavan123` |
| 102 | `kapilesh` | `kapil` | Kapilesh N | USER | `kapilesh123` |
| 103 | `sakthivel` | `sakthi` | Sakthivel B | USER | `sakthivel123` |
| 104 | `chinmayanand` | `chinmay` | Agnihotram Chinmayanand | ADMIN | `chinmayanand123` |

`alice`, `bob`, and `charlie` should no longer be database usernames or login aliases.

## 1. Replace `app/seed.py`

Use the `app/seed.py` file included in this bundle. It keeps user IDs and ownership relationships aligned with the table above. Object IDs and user IDs belong to separate tables; object 103 is owned by user 104, and object 104 is owned by user 103.

**Warning:** `seed_database()` deletes and recreates the database configured by `settings.DATABASE_URL`. Back up your development database before running `python -m app.seed`. Test fixtures that explicitly switch to disposable test database URLs can seed those test databases as usual.

## 2. Replace `LOGIN_USERNAME_ALIASES` in `app/main.py`

```python
LOGIN_USERNAME_ALIASES = {
    "balanilavan": "bala",
    "bala": "balanilavan",
    "kapilesh": "kapil",
    "kapil": "kapilesh",
    "sakthivel": "sakthi",
    "sakthi": "sakthivel",
    "chinmayanand": "chinmay",
    "chinmay": "chinmayanand",
}
```

The existing login function checks the requested username and then its alias using the same password hash, so the aliases authenticate to the same canonical database account.

## 3. Replace the `demo_users` persona tuple in `get_dashboard_stats()`

```python
for persona in (
    {
        "username": "chinmayanand",
        "legacy_username": "chinmay",
        "display_name": "Agnihotram Chinmayanand",
        "role": "ADMIN",
    },
    {
        "username": "balanilavan",
        "legacy_username": "bala",
        "display_name": "B.V. Balanilavan",
        "role": "USER",
    },
    {
        "username": "kapilesh",
        "legacy_username": "kapil",
        "display_name": "Kapilesh N",
        "role": "USER",
    },
    {
        "username": "sakthivel",
        "legacy_username": "sakthi",
        "display_name": "Sakthivel B",
        "role": "USER",
    },
):
```

Update the username `CASE` expressions used to display actor names in audit-log SQL to use these username spellings:

```sql
CASE u.username
    WHEN 'chinmayanand' THEN 'Agnihotram Chinmayanand'
    WHEN 'chinmay' THEN 'Agnihotram Chinmayanand'
    WHEN 'balanilavan' THEN 'B.V. Balanilavan'
    WHEN 'bala' THEN 'B.V. Balanilavan'
    WHEN 'kapilesh' THEN 'Kapilesh N'
    WHEN 'kapil' THEN 'Kapilesh N'
    WHEN 'sakthivel' THEN 'Sakthivel B'
    WHEN 'sakthi' THEN 'Sakthivel B'
    ELSE u.username
END
```

There are multiple `CASE` expressions in `app/main.py`; update each old username-display mapping in those expressions. Remove the `alice`, `bob`, and `charlie` cases.

## 4. Update tests that assign an admin identity

Any test that currently creates an admin token for user ID 103 must use user ID 104, because user 103 is now Sakthivel and user 104 is Chinmayanand. In `tests/test_non_interference.py`, change the admin token call to:

```python
headers=user_headers(user_id=104, role="admin"),
```

Search all tests for `user_id=103` or `user_id = 103` and review each match; change only those that refer to the admin account. Keep the BOLA fixture's resource IDs 101/102/201/202/203 unchanged. User IDs and resource IDs are not the same namespace.

## 5. Search for stale names and test

```powershell
Get-ChildItem app,tests -Recurse -Include *.py |
    Select-String -Pattern '\balice\b|\bbob\b|\bcharlie\b|user_id\s*=\s*103'
```

Review each match. Replace obsolete login or display-name references, but don't blindly replace words in unrelated documentation.

Run focused tests and the full test suite:

```powershell
python -m pytest tests/test_implicit_relationship_bola.py -q
python -m pytest tests/test_non_interference.py -q
python -m pytest tests/test_runtime_object_guard_unit.py -q
python -m pytest -q
```

## 6. Verify login aliases

Use the API login endpoint with each canonical username and its legacy alias. These pairs should authenticate to the same user ID when used with that account's seeded password:

- `balanilavan` / `bala`
- `kapilesh` / `kapil`
- `sakthivel` / `sakthi`
- `chinmayanand` / `chinmay`

The seed function only sets up disposable/demo credentials; replace them with secure credential handling before any production use.
