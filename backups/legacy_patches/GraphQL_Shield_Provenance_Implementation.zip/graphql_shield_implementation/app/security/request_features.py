"""Feature extraction for request-level BOLA risk experiments."""
from __future__ import annotations

import json
import hashlib
from typing import Any

from graphql import (
    FieldNode,
    FragmentDefinitionNode,
    FragmentSpreadNode,
    InlineFragmentNode,
    OperationDefinitionNode,
    parse,
)

FEATURE_COLUMNS = [
    "query_depth",
    "alias_count",
    "field_count",
    "object_id_argument_count",
    "nested_relationship_depth",
    "unique_objects_touched",
    "cross_owner_attempts",
    "authorization_denials",
    "protected_relationships",
    "objects_returned",
    "objects_filtered",
    "response_bytes",
    "recent_distinct_object_ids_5m",
    "recent_denials_5m",
]


def query_template_id(query: str | None) -> str:
    """Hash query structure while ignoring argument values and literal IDs."""
    if not query:
        return "unknown"
    try:
        document = parse(query)
    except Exception:
        return "invalid"

    fragments = {
        definition.name.value: definition
        for definition in document.definitions
        if isinstance(definition, FragmentDefinitionNode)
    }
    pieces: list[str] = []

    def visit(selection_set, prefix: str, stack: frozenset[str]) -> None:
        if selection_set is None:
            return
        for selection in selection_set.selections:
            if isinstance(selection, FieldNode):
                field_name = selection.name.value
                alias = selection.alias.value if selection.alias else ""
                argument_names = sorted(arg.name.value for arg in (selection.arguments or ()))
                pieces.append(f"{prefix}/{alias}:{field_name}({','.join(argument_names)})")
                visit(selection.selection_set, f"{prefix}/{alias}:{field_name}", stack)
            elif isinstance(selection, InlineFragmentNode):
                type_name = selection.type_condition.name.value if selection.type_condition else ""
                visit(selection.selection_set, f"{prefix}/...{type_name}", stack)
            elif isinstance(selection, FragmentSpreadNode):
                name = selection.name.value
                fragment = fragments.get(name)
                if fragment is not None and name not in stack:
                    visit(fragment.selection_set, f"{prefix}/fragment:{name}", stack | {name})

    for definition in document.definitions:
        if isinstance(definition, OperationDefinitionNode):
            op_name = definition.name.value if definition.name else "anonymous"
            pieces.append(f"operation:{definition.operation.value}:{op_name}")
            visit(definition.selection_set, "", frozenset())

    raw = "\n".join(pieces)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:20]


def _query_shape(query: str | None) -> dict[str, int]:
    stats = {"query_depth": 0, "alias_count": 0, "field_count": 0, "object_id_argument_count": 0}
    if not query:
        return stats
    try:
        document = parse(query)
    except Exception:
        return stats

    fragments = {
        definition.name.value: definition
        for definition in document.definitions
        if isinstance(definition, FragmentDefinitionNode)
    }

    def visit(selection_set, depth: int, stack: frozenset[str]) -> None:
        if selection_set is None:
            return
        for selection in selection_set.selections:
            if isinstance(selection, FieldNode):
                stats["field_count"] += 1
                stats["query_depth"] = max(stats["query_depth"], depth + 1)
                if selection.alias is not None:
                    stats["alias_count"] += 1
                for arg in selection.arguments or ():
                    if arg.name.value.lower() in {"id", "resourceid", "objectid"}:
                        stats["object_id_argument_count"] += 1
                visit(selection.selection_set, depth + 1, stack)
            elif isinstance(selection, InlineFragmentNode):
                visit(selection.selection_set, depth, stack)
            elif isinstance(selection, FragmentSpreadNode):
                name = selection.name.value
                fragment = fragments.get(name)
                if fragment is not None and name not in stack:
                    visit(fragment.selection_set, depth, stack | {name})

    for definition in document.definitions:
        if isinstance(definition, OperationDefinitionNode):
            visit(definition.selection_set, 0, frozenset())

    stats["nested_relationship_depth"] = max(stats["query_depth"] - 1, 0)
    return stats


def _recent_activity(user_id: int | None) -> tuple[int, int]:
    if user_id is None:
        return 0, 0
    try:
        from app.database import get_db_connection
        conn = get_db_connection()
        try:
            cursor = conn.cursor()
            cursor.execute(
                """SELECT COUNT(DISTINCT object_id) FROM audit_logs
                   WHERE user_id = ? AND timestamp >= datetime('now', '-5 minutes')""",
                (user_id,),
            )
            distinct_ids = int(cursor.fetchone()[0] or 0)
            cursor.execute(
                """SELECT COUNT(*) FROM audit_logs
                   WHERE user_id = ? AND decision = 'DENY'
                     AND timestamp >= datetime('now', '-5 minutes')""",
                (user_id,),
            )
            denials = int(cursor.fetchone()[0] or 0)
            return distinct_ids, denials
        finally:
            conn.close()
    except Exception:
        # Missing audit tables during isolated tests should not break enforcement.
        return 0, 0


def build_request_features(
    *,
    query: str | None,
    state: Any,
    user_id: int | None,
    response_data: Any = None,
) -> dict[str, int]:
    """Create the stable numeric feature vector used for model training/inference."""
    features = _query_shape(query)
    evidence = list(getattr(state, "authorization_evidence", []) or [])
    provenance = list(getattr(state, "provenance", []) or [])

    touched_ids = {
        str(item.get("object_id"))
        for item in evidence
        if item.get("object_id") is not None
    }
    cross_owner = 0
    denials = 0
    returned = 0
    filtered = 0
    for item in evidence:
        principal = item.get("principal_id")
        owner = item.get("owner_id")
        if (
            owner is not None
            and principal is not None
            and str(owner) != str(principal)
            and item.get("decision") == "DENY"
        ):
            # Count rejected cross-owner attempts, not legitimate administrator
            # access, as a suspicious cross-owner pattern.
            cross_owner += 1
        if item.get("decision") == "DENY":
            denials += 1
            if item.get("enforcement") in {"filtered", "replaced_with_null", "gateway_blocked"}:
                filtered += 1
        elif item.get("decision") == "ALLOW" and item.get("enforcement") == "returned":
            returned += 1

    try:
        response_bytes = len(
            json.dumps(response_data, separators=(",", ":"), default=str).encode("utf-8")
        ) if response_data is not None else 0
    except Exception:
        response_bytes = 0

    recent_ids, recent_denials = _recent_activity(user_id)
    features.update({
        "unique_objects_touched": len(touched_ids),
        "cross_owner_attempts": cross_owner,
        "authorization_denials": denials,
        "protected_relationships": sum(1 for item in provenance if item.get("provenance", {}).get("edges")),
        "objects_returned": returned,
        "objects_filtered": filtered,
        "response_bytes": response_bytes,
        "recent_distinct_object_ids_5m": recent_ids,
        "recent_denials_5m": recent_denials,
    })
    return {column: int(features.get(column, 0)) for column in FEATURE_COLUMNS}
