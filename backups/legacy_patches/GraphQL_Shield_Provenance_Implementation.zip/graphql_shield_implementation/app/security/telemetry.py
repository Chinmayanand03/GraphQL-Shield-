"""Request-level telemetry and optional ML assessment."""
from __future__ import annotations

import logging
import json
import os
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.security.ml_risk_detector import score_request
from app.security.provenance import get_request_security_state
from app.security.request_features import build_request_features, query_template_id

logger = logging.getLogger("graphql_shield.telemetry")
_write_lock = threading.Lock()


def assess_request(request: Any, response_data: Any = None) -> dict[str, Any]:
    """Compute features and score the request if a trained model is available.

    This function is advisory. It must never make or override an access decision.
    """
    context = {"request": request}
    state = get_request_security_state(context)
    current_user = getattr(getattr(request, "state", None), "current_user", None)
    try:
        user_id = int(current_user.get("user_id")) if isinstance(current_user, dict) else None
    except (TypeError, ValueError):
        user_id = None
    query = str(getattr(request.state, "graphql_shield_query", "") or "")
    features = build_request_features(
        query=query,
        state=state,
        user_id=user_id,
        response_data=response_data,
    )
    result = score_request(features)
    state.ml_risk = result

    # Optional privacy-conscious JSONL capture for building a manually labelled
    # training set. Raw GraphQL text, response bodies, and principal IDs are not
    # written. Set GRAPHQL_SHIELD_TELEMETRY_FILE to enable it.
    output_text = os.getenv("GRAPHQL_SHIELD_TELEMETRY_FILE", "").strip()
    if output_text:
        record = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "query_template_id": query_template_id(query),
            **features,
            "model_status": result.get("status"),
            "model_prediction": result.get("prediction"),
            "model_risk_score": result.get("risk_score"),
        }
        try:
            output_path = Path(output_text)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with _write_lock, output_path.open("a", encoding="utf-8") as file:
                file.write(json.dumps(record, separators=(",", ":")) + "\n")
        except Exception:
            logger.exception("Could not append GraphQL Shield telemetry record")

    logger.info(
        "GraphQL Shield ML assessment status=%s score=%s prediction=%s",
        result.get("status"),
        result.get("risk_score"),
        result.get("prediction"),
    )
    return result
