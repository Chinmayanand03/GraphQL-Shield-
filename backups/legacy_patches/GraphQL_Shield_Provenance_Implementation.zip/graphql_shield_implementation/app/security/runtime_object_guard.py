"""Runtime object-level authorization for Strawberry GraphQL.

Scope: protects ResourceType objects returned by resolvers on the exact
'/graphql' route. '/graphql-insecure' intentionally bypasses this extension so
it remains a benchmark baseline. Ownership is always re-read from SQLite.
"""
from __future__ import annotations

import inspect
import logging
from typing import Any, Iterable

from graphql import GraphQLError
from strawberry.extensions import SchemaExtension

from app.graphql.types import ResourceType
from app.security.audit import log_decision
from app.security.authorization import AuthorizationContext, PolicyEngine
from app.security.ownership import get_object_owner
from app.security.telemetry import assess_request
from app.security.provenance import (
    get_request_security_state,
    path_list,
    path_to_string,
    record_authorization,
    record_provenance,
    request_from_context,
)

logger = logging.getLogger("graphql_shield.runtime_guard")


def _request_path(request: Any | None) -> str:
    return str(getattr(getattr(request, "url", None), "path", "")).rstrip("/")


def _current_user(request: Any | None) -> dict[str, Any] | None:
    state = getattr(request, "state", None)
    user = getattr(state, "current_user", None)
    return user if isinstance(user, dict) else None


def _resolve_path(info: Any) -> list[str | int]:
    try:
        return list(info.path.as_list())
    except Exception:
        return [str(getattr(info, "field_name", "unknown"))]


def _operation(info: Any) -> str:
    try:
        return str(info.operation.operation.value).lower()
    except Exception:
        return "query"


def _parent_identity(root: Any) -> tuple[str | None, int | None]:
    if root is None:
        return None, None
    raw_id = getattr(root, "id", None)
    try:
        parent_id = int(raw_id)
    except (TypeError, ValueError):
        return None, None
    class_name = type(root).__name__
    if class_name.endswith("Type"):
        class_name = class_name[:-4]
    return class_name, parent_id


def _read_path(data: Any, path: Iterable[str | int]) -> Any:
    current = data
    for part in path:
        if isinstance(part, str) and isinstance(current, dict):
            current = current.get(part)
        elif isinstance(part, int) and isinstance(current, list) and 0 <= part < len(current):
            current = current[part]
        else:
            return None
    return current


def _append_closure_error(result: Any, message: str) -> None:
    """Fail closed if the tracked object/output correspondence is inconsistent."""
    result.data = None
    errors = list(getattr(result, "errors", None) or [])
    errors.append(
        GraphQLError(
            message,
            extensions={"code": "GRAPHQL_SHIELD_RESPONSE_CLOSURE_FAILED"},
        )
    )
    result.errors = errors


class RuntimeObjectAuthorizationExtension(SchemaExtension):
    """Authorize concrete ResourceType results before GraphQL resolves their fields."""

    def __init__(self, *, execution_context=None) -> None:
        super().__init__(execution_context=execution_context)
        self.policy_engine = PolicyEngine()

    def resolve(self, _next, root, info, *args, **kwargs):
        value = _next(root, info, *args, **kwargs)
        if inspect.isawaitable(value):
            async def resolve_and_guard():
                resolved = await value
                return self._guard_result(resolved, root, info)
            return resolve_and_guard()
        return self._guard_result(value, root, info)

    def _guard_result(self, value: Any, root: Any, info: Any) -> Any:
        context = getattr(info, "context", None)
        request = request_from_context(context)
        route = _request_path(request)

        # Exact route check is essential: the app deliberately exposes an
        # insecure benchmark endpoint that shares the same Strawberry schema.
        if route != "/graphql":
            return value

        state = get_request_security_state(context)
        path = _resolve_path(info)
        parent_type, parent_id = _parent_identity(root)
        relationship_field = str(getattr(info, "field_name", ""))

        if isinstance(value, ResourceType):
            allowed, cleaned = self._authorize_one(
                value=value,
                info=info,
                path=path,
                emitted_path=path,
                parent_type=parent_type,
                parent_id=parent_id,
                relationship_field=relationship_field,
                state=state,
                request=request,
            )
            return cleaned if allowed else None

        if isinstance(value, list):
            filtered: list[Any] = []
            for original_index, item in enumerate(value):
                if not isinstance(item, ResourceType):
                    filtered.append(item)
                    continue

                candidate_path = path + [original_index]
                emitted_path = path + [len(filtered)]
                allowed, cleaned = self._authorize_one(
                    value=item,
                    info=info,
                    path=candidate_path,
                    emitted_path=emitted_path if self._can_be_emitted(item, request) else None,
                    parent_type=parent_type,
                    parent_id=parent_id,
                    relationship_field=relationship_field,
                    state=state,
                    request=request,
                )
                if allowed:
                    filtered.append(cleaned)
            return filtered

        if isinstance(value, tuple):
            guarded = self._guard_result(list(value), root, info)
            return tuple(guarded)

        return value

    @staticmethod
    def _can_be_emitted(value: ResourceType, request: Any | None) -> bool:
        # Only used to shape evidence paths. It does not make the security decision.
        return request is not None

    def _authorize_one(
        self,
        *,
        value: ResourceType,
        info: Any,
        path: list[str | int],
        emitted_path: list[str | int] | None,
        parent_type: str | None,
        parent_id: int | None,
        relationship_field: str,
        state: Any,
        request: Any | None,
    ) -> tuple[bool, ResourceType | None]:
        current_user = _current_user(request)
        principal_id: int | None = None
        role = "USER"
        if current_user:
            try:
                principal_id = int(current_user.get("user_id"))
            except (TypeError, ValueError):
                principal_id = None
            role = str(current_user.get("role", "USER")).upper()

        raw_object_id = getattr(value, "id", None)
        try:
            if isinstance(raw_object_id, bool):
                raise ValueError("boolean is not a valid object id")
            object_id = int(raw_object_id)
            if object_id < 1:
                raise ValueError("object id must be positive")
        except (TypeError, ValueError):
            self._record_denial(
                state=state,
                principal_id=principal_id,
                object_id=None,
                owner_id=None,
                path=path,
                emitted_path=emitted_path,
                reason="INVALID_OBJECT_ID",
            )
            return False, None

        # The returned object's owner_id is not trusted. Fetch the canonical
        # owner using the repository's existing authoritative lookup.
        try:
            owner_id = get_object_owner("Resource", object_id)
            owner_id = int(owner_id) if owner_id is not None else None
        except Exception:
            logger.exception("Trusted owner lookup failed for resource %s", object_id)
            self._record_denial(
                state=state,
                principal_id=principal_id,
                object_id=object_id,
                owner_id=None,
                path=path,
                emitted_path=emitted_path,
                reason="OWNER_LOOKUP_FAILED",
            )
            return False, None

        if principal_id is None:
            self._record_denial(
                state=state,
                principal_id=None,
                object_id=object_id,
                owner_id=owner_id,
                path=path,
                emitted_path=emitted_path,
                reason="MISSING_AUTHENTICATED_PRINCIPAL",
            )
            return False, None

        resolver_owner = getattr(value, "owner_id", None)
        try:
            resolver_owner_int = int(resolver_owner) if resolver_owner is not None else None
        except (TypeError, ValueError):
            resolver_owner_int = None

        # If resolver data conflicts with the canonical database owner, treat it
        # as an integrity failure rather than emitting a misleading owner field.
        if owner_id is not None and resolver_owner_int != owner_id:
            self._record_denial(
                state=state,
                principal_id=principal_id,
                object_id=object_id,
                owner_id=owner_id,
                path=path,
                emitted_path=emitted_path,
                reason="OWNER_METADATA_MISMATCH",
            )
            return False, None

        context = AuthorizationContext(
            user_id=principal_id,
            role=role,
            operation=_operation(info),
            object_type="Resource",
            object_id=object_id,
            path=path_to_string(path),
            owner_id=owner_id,
            metadata={
                "source_table": "objects",
                "graphql_field": str(getattr(info, "field_name", "unknown")),
                "relationship_parent_type": parent_type,
                "relationship_parent_id": parent_id,
            },
        )
        decision = self.policy_engine.evaluate(context)
        allowed = decision.get("decision") == "ALLOW"
        reason = str(decision.get("reason", "UNKNOWN_POLICY_RESULT"))

        record_provenance(
            state,
            object_type="Resource",
            object_id=object_id,
            owner_id=owner_id,
            graphql_path=path,
            parent_type=parent_type,
            parent_id=parent_id,
            relationship_field=relationship_field,
            emitted_path=emitted_path if allowed else None,
        )

        record_authorization(
            state,
            principal_id=principal_id,
            action="read",
            object_type="Resource",
            object_id=object_id,
            owner_id=owner_id,
            graphql_path=path,
            decision="ALLOW" if allowed else "DENY",
            reason=reason,
            evidence_source="runtime_object_guard+trusted_sqlite_owner_lookup",
            enforcement="returned" if allowed else ("filtered" if emitted_path is None or isinstance(emitted_path[-1], int) else "replaced_with_null"),
            emitted_path=emitted_path if allowed else None,
        )
        self._write_audit(
            principal_id=principal_id,
            role=role,
            operation=context.operation,
            object_id=object_id,
            path=context.path,
            decision=decision,
        )

        return (True, value) if allowed else (False, None)

    def _record_denial(
        self,
        *,
        state: Any,
        principal_id: int | None,
        object_id: int | None,
        owner_id: int | None,
        path: list[str | int],
        emitted_path: list[str | int] | None,
        reason: str,
    ) -> None:
        record_authorization(
            state,
            principal_id=principal_id,
            action="read",
            object_type="Resource",
            object_id=object_id,
            owner_id=owner_id,
            graphql_path=path,
            decision="DENY",
            reason=reason,
            evidence_source="runtime_object_guard",
            enforcement="filtered",
            emitted_path=None,
        )
        if principal_id is not None and object_id is not None:
            self._write_audit(
                principal_id=principal_id,
                role="USER",
                operation="query",
                object_id=object_id,
                path=path_to_string(path),
                decision={"decision": "DENY", "reason": reason, "risk_score": 100, "risk_level": "HIGH"},
            )

    @staticmethod
    def _write_audit(
        *,
        principal_id: int,
        role: str,
        operation: str,
        object_id: int,
        path: str,
        decision: dict[str, Any],
    ) -> None:
        try:
            log_decision(
                user_id=principal_id,
                role=role,
                operation=operation,
                object_type="Resource",
                object_id=object_id,
                path=path,
                decision=str(decision.get("decision", "DENY")),
                reason=str(decision.get("reason", "UNKNOWN")),
                risk_score=int(decision.get("risk_score", 0)),
                risk_level=str(decision.get("risk_level", "LOW")),
            )
        except Exception:
            # Audit failure must never turn a DENY into an ALLOW or crash the
            # resolver before its enforcement decision is applied.
            logger.exception("Could not persist GraphQL Shield authorization audit event")

    def on_operation(self):
        """Verify that every allowed ResourceType occurrence is present at its
        recorded output path. This is a consistency backstop, not a universal
        detector for secret-derived scalar values or uninstrumented data sources.
        """
        yield
        context = getattr(self.execution_context, "context", None)
        request = request_from_context(context)
        if _request_path(request) != "/graphql":
            return

        state = get_request_security_state(context)
        result = getattr(self.execution_context, "result", None)
        if result is None:
            state.response_closure = {"status": "NO_EXECUTION_RESULT", "violations": []}
            return
        if getattr(result, "errors", None):
            state.response_closure = {
                "status": "INCONCLUSIVE_GRAPHQL_ERRORS",
                "violations": [],
            }
            return

        violations: list[dict[str, Any]] = []
        for evidence in state.authorization_evidence:
            if evidence.get("evidence_source") != "runtime_object_guard+trusted_sqlite_owner_lookup":
                continue
            if evidence.get("decision") != "ALLOW":
                continue
            emitted_path = evidence.get("emitted_path")
            if emitted_path is None:
                violations.append({"reason": "ALLOW_WITHOUT_EMITTED_PATH", "evidence": evidence})
                continue
            output_value = _read_path(getattr(result, "data", None), emitted_path)
            if not isinstance(output_value, dict):
                violations.append({
                    "reason": "AUTHORIZED_OBJECT_MISSING_AT_OUTPUT_PATH",
                    "path": emitted_path,
                    "object_id": evidence.get("object_id"),
                })

        state.response_closure = {
            "status": "FAILED" if violations else "PASS",
            "violations": violations,
            "checked_authorized_objects": sum(
                1 for e in state.authorization_evidence
                if e.get("evidence_source") == "runtime_object_guard+trusted_sqlite_owner_lookup"
                and e.get("decision") == "ALLOW"
            ),
        }
        if violations:
            logger.error("GraphQL Shield response closure failed: %s", violations)
            _append_closure_error(result, "GraphQL Shield response authorization closure failed")

        # ML is advisory only. A missing/untrained model produces status UNTRAINED
        # and never changes the already-enforced PolicyEngine decision.
        try:
            assess_request(request, response_data=getattr(result, "data", None))
        except Exception:
            logger.exception("Could not compute GraphQL Shield request risk features")
            state.ml_risk = {"status": "FEATURE_EXTRACTION_ERROR", "risk_score": None, "prediction": None}
