"""Optional XGBoost inference. ML is advisory and never authorizes access."""
from __future__ import annotations

import logging
import os
from functools import lru_cache
from pathlib import Path
from typing import Any

from app.security.request_features import FEATURE_COLUMNS

logger = logging.getLogger("graphql_shield.ml")
DEFAULT_MODEL_PATH = Path(__file__).resolve().parents[2] / "models" / "bola_xgboost.json"


@lru_cache(maxsize=4)
def _load_model(path_text: str, mtime_ns: int):
    # Import XGBoost lazily so the API still starts when the optional ML extras
    # have not been installed or the model has not been trained yet.
    from xgboost import XGBClassifier
    model = XGBClassifier()
    model.load_model(path_text)
    return model


def score_request(features: dict[str, Any], model_path: str | os.PathLike[str] | None = None) -> dict[str, Any]:
    """Return a risk score if a trained model is available; otherwise be explicit."""
    path = Path(model_path) if model_path is not None else DEFAULT_MODEL_PATH
    if not path.is_file():
        return {
            "status": "UNTRAINED",
            "model": "XGBoost",
            "risk_score": None,
            "prediction": None,
            "message": "No trained model found; authorization policy remains authoritative.",
        }

    try:
        import pandas as pd
        model = _load_model(str(path.resolve()), path.stat().st_mtime_ns)
        row = {column: float(features.get(column, 0)) for column in FEATURE_COLUMNS}
        frame = pd.DataFrame([row], columns=FEATURE_COLUMNS)
        probabilities = model.predict_proba(frame)[0]
        classes = list(model.classes_)
        suspicious_index = classes.index(1) if 1 in classes else -1
        probability = float(probabilities[suspicious_index]) if suspicious_index >= 0 else 0.0
        prediction = int(model.predict(frame)[0])
        return {
            "status": "READY",
            "model": "XGBoost",
            "risk_score": round(probability * 100, 2),
            "prediction": prediction,
            "risk_level": "HIGH" if probability >= 0.75 else "MEDIUM" if probability >= 0.40 else "LOW",
            "features": row,
        }
    except Exception as exc:
        logger.exception("XGBoost inference failed")
        return {
            "status": "MODEL_ERROR",
            "model": "XGBoost",
            "risk_score": None,
            "prediction": None,
            "message": str(exc),
        }
