"""Request-scoped execution provenance and authorization evidence for GraphQL Shield.

This module intentionally records JSON-serializable metadata only. It never trusts
owner IDs supplied by a GraphQL client; the runtime guard must populate owner_id
from the persistence layer.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Sequence

PathPart = str | int


def request_from_context(context: Any) -> Any | None:
    """Return the Starlette request from the default Strawberry/FastAPI context."""
    if isinstance(context, dict):
        return context.get("request")
    return getattr(context, "request", None)


@dataclass(slots=True)
class RequestSecurityState:
    """Mutable state scoped to one GraphQL HTTP request."""

    provenance: list[dict[str, Any]] = field(default_factory=list)
    authorization_evidence: list[dict[str, Any]] = field(default_factory=list)
    ml_risk: dict[str, Any] = field(default_factory=lambda: {"status": "NOT_EVALUATED"})
    response_closure: dict[str, Any] = field(default_factory=lambda: {"status": "NOT_CHECKED"})


def get_request_security_state(context: Any) -> RequestSecurityState:
    """Get or create request-local state; it is not shared across requests."""
    request = request_from_context(context)
    if request is not None:
        request_state = getattr(request, "state", None)
        if request_state is not None:
            state = getattr(request_state, "graphql_shield_security", None)
            if state is None:
                state = RequestSecurityState()
                setattr(request_state, "graphql_shield_security", state)
            return state

    # Useful for schema.execute() tests using a dict context. Production HTTP
    # traffic should have a FastAPI request and use request.state above.
    if isinstance(context, dict):
        state = context.get("_graphql_shield_security")
        if state is None:
            state = RequestSecurityState()
            context["_graphql_shield_security"] = state
        return state

    state = getattr(context, "_graphql_shield_security", None)
    if state is None:
        state = RequestSecurityState()
        try:
            setattr(context, "_graphql_shield_security", state)
        except Exception:
            # No request/context storage available. The caller can still enforce
            # policy; it simply cannot expose the provenance ledger afterwards.
            pass
    return state


def path_list(path: Sequence[PathPart] | None) -> list[PathPart]:
    return list(path or ())


def path_to_string(path: Sequence[PathPart] | None) -> str:
    return ".".join(str(part) for part in (path or ()))


def record_provenance(
    state: RequestSecurityState,
    *,
    object_type: str,
    object_id: int,
    owner_id: int | None,
    graphql_path: Sequence[PathPart],
    parent_type: str | None = None,
    parent_id: int | None = None,
    relationship_field: str | None = None,
    emitted_path: Sequence[PathPart] | None = None,
) -> None:
    """Record source-row and relationship lineage for one executed object."""
    record = {
        "object_type": object_type,
        "object_id": int(object_id),
        "owner_id": int(owner_id) if owner_id is not None else None,
        "source": {"table": "objects", "primary_key": str(object_id)},
        "provenance": {
            "rows": [{"table": "objects", "id": str(object_id)}],
            "edges": (
                [{
                    "parent_type": parent_type,
                    "parent_id": str(parent_id),
                    "field": relationship_field,
                    "child_type": object_type,
                    "child_id": str(object_id),
                }]
                if parent_type is not None and parent_id is not None and relationship_field
                else []
            ),
        },
        # This is the path of the execution occurrence, which may differ from
        # emitted_path for an item filtered from a list.
        "graphql_path": path_list(graphql_path),
        "emitted_path": path_list(emitted_path) if emitted_path is not None else None,
    }
    state.provenance.append(record)


def record_authorization(
    state: RequestSecurityState,
    *,
    principal_id: int | None,
    action: str,
    object_type: str,
    object_id: int | None,
    owner_id: int | None,
    graphql_path: Sequence[PathPart],
    decision: str,
    reason: str,
    evidence_source: str,
    enforcement: str,
    emitted_path: Sequence[PathPart] | None = None,
) -> None:
    def safe_int(value: Any) -> int | None:
        if value is None or isinstance(value, bool):
            return None
        try:
            return int(value)
        except (TypeError, ValueError):
            return None

    state.authorization_evidence.append(
        {
            "principal_id": safe_int(principal_id),
            "action": action,
            "object_type": object_type,
            "object_id": safe_int(object_id),
            "owner_id": safe_int(owner_id),
            "graphql_path": path_list(graphql_path),
            "decision": decision,
            "reason": reason,
            "evidence_source": evidence_source,
            "enforcement": enforcement,
            "emitted_path": path_list(emitted_path) if emitted_path is not None else None,
        }
    )
