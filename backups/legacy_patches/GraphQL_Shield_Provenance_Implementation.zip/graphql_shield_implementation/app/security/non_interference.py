"""Helpers for differential non-interference experiments.

These helpers compare responses. The test author remains responsible for specifying
which response fields the principal is authorized to observe and for changing only
confidential data between the paired runs.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Iterable


def normalize_response(value: Any, *, ignored_keys: Iterable[str] = ()) -> Any:
    """Normalize JSON-compatible GraphQL data without discarding meaningful values."""
    ignored = set(ignored_keys)
    if isinstance(value, dict):
        return {
            key: normalize_response(item, ignored_keys=ignored)
            for key, item in sorted(value.items())
            if key not in ignored
        }
    if isinstance(value, list):
        return [normalize_response(item, ignored_keys=ignored) for item in value]
    return value


def compare_observations(
    before: Any,
    after: Any,
    *,
    ignored_keys: Iterable[str] = (),
) -> dict[str, Any]:
    """Compare two observations for a fixed principal and equivalent public state."""
    normalized_before = normalize_response(before, ignored_keys=ignored_keys)
    normalized_after = normalize_response(after, ignored_keys=ignored_keys)
    before_json = json.dumps(normalized_before, sort_keys=True, separators=(",", ":"), default=str)
    after_json = json.dumps(normalized_after, sort_keys=True, separators=(",", ":"), default=str)
    before_hash = hashlib.sha256(before_json.encode("utf-8")).hexdigest()
    after_hash = hashlib.sha256(after_json.encode("utf-8")).hexdigest()
    return {
        "non_interference_passed": before_json == after_json,
        "before_sha256": before_hash,
        "after_sha256": after_hash,
        "before_normalized": normalized_before,
        "after_normalized": normalized_after,
        "difference": None if before_json == after_json else {
            "before": normalized_before,
            "after": normalized_after,
        },
    }
