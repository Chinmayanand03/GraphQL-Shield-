# Required small integration changes

## A. `app/graphql/schema.py`
Replace the current two-line schema definition with the `schema.py` file in this bundle.

## B. `app/security/enforcement.py`
Immediately after the current lines that read `query` and `variables` from parsed POST JSON, add:

```python
request.state.graphql_shield_query = query if isinstance(query, str) else ""
request.state.graphql_shield_variables = variables if isinstance(variables, dict) else {}
```

This does not replace the current request-level enforcement. That gateway should continue to block explicit foreign object IDs. The new runtime extension protects concrete `ResourceType` objects that are returned implicitly by resolvers.

## C. Dependencies
The existing `requirements.txt` already includes Strawberry GraphQL, Pytest, and FastAPI. Install the optional ML dependencies only when preparing the model training dataset:

```powershell
pip install -r requirements-ml.txt
```

The API can start without these optional packages if no model is trained; `ml_risk_detector.py` imports XGBoost lazily.
