import strawberry
from app.graphql.queries import Query
from app.security.runtime_object_guard import RuntimeObjectAuthorizationExtension

# The extension protects /graphql. It explicitly skips /graphql-insecure so the
# intentionally vulnerable endpoint remains available for controlled benchmarks.
schema = strawberry.Schema(
    query=Query,
    extensions=[RuntimeObjectAuthorizationExtension],
)
