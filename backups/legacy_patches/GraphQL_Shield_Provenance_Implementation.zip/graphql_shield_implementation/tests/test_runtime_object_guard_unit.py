from types import SimpleNamespace

import pytest

from app.graphql.types import ResourceType
from app.security.provenance import get_request_security_state
from app.security.runtime_object_guard import RuntimeObjectAuthorizationExtension


class FakePath:
    def __init__(self, parts):
        self._parts = parts

    def as_list(self):
        return list(self._parts)


def make_info(request, path_parts=("resource", "children"), field_name="children"):
    return SimpleNamespace(
        context={"request": request},
        path=FakePath(path_parts),
        field_name=field_name,
        operation=SimpleNamespace(operation=SimpleNamespace(value="query")),
    )


def make_request(user_id=1, role="USER", path="/graphql"):
    return SimpleNamespace(
        url=SimpleNamespace(path=path),
        state=SimpleNamespace(current_user={"user_id": user_id, "role": role}),
    )


def make_resource(resource_id, owner_id, parent_id=None):
    return ResourceType(
        id=resource_id,
        name=f"resource-{resource_id}",
        owner_id=owner_id,
        object_type="document",
        parent_id=parent_id,
    )


def make_extension(request):
    # The base extension keeps the supplied execution_context for lifecycle hooks.
    execution_context = SimpleNamespace(context={"request": request}, result=None)
    return RuntimeObjectAuthorizationExtension(execution_context=execution_context)


def test_nested_foreign_owned_child_is_filtered(monkeypatch):
    request = make_request()
    extension = make_extension(request)
    monkeypatch.setattr(
        "app.security.runtime_object_guard.get_object_owner",
        lambda object_type, object_id: {102: 2, 202: 1}[object_id],
    )
    monkeypatch.setattr("app.security.runtime_object_guard.log_decision", lambda **kwargs: None)

    parent = make_resource(201, 1)
    result = extension._guard_result(
        [make_resource(102, 2, 201), make_resource(202, 1, 201)],
        parent,
        make_info(request),
    )

    assert [item.id for item in result] == [202]
    state = get_request_security_state({"request": request})
    assert any(e["object_id"] == 102 and e["decision"] == "DENY" for e in state.authorization_evidence)
    assert any(e["object_id"] == 202 and e["decision"] == "ALLOW" for e in state.authorization_evidence)
    provenance = next(p for p in state.provenance if p["object_id"] == 202)
    assert provenance["source"]["table"] == "objects"
    assert provenance["provenance"]["edges"][0]["parent_id"] == "201"
    assert provenance["provenance"]["edges"][0]["field"] == "children"


def test_admin_can_access_foreign_owned_resource(monkeypatch):
    request = make_request(user_id=3, role="ADMIN")
    extension = make_extension(request)
    monkeypatch.setattr("app.security.runtime_object_guard.get_object_owner", lambda *_: 2)
    monkeypatch.setattr("app.security.runtime_object_guard.log_decision", lambda **kwargs: None)

    result = extension._guard_result(
        make_resource(102, 2),
        None,
        make_info(request, path_parts=("resource",), field_name="resource"),
    )
    assert result is not None
    assert result.id == 102


def test_insecure_route_bypasses_runtime_guard(monkeypatch):
    request = make_request(path="/graphql-insecure")
    extension = make_extension(request)
    monkeypatch.setattr(
        "app.security.runtime_object_guard.get_object_owner",
        lambda *_: pytest.fail("owner lookup must not run on the intentionally insecure route"),
    )
    resource = make_resource(102, 2)
    result = extension._guard_result(
        resource,
        None,
        make_info(request, path_parts=("resource",), field_name="resource"),
    )
    assert result is resource
