from app.security.non_interference import compare_observations, normalize_response


def test_identical_authorized_views_pass_non_interference_comparison():
    before = {"data": {"resource": {"id": 201, "name": "Alice folder"}}}
    after = {"data": {"resource": {"id": 201, "name": "Alice folder"}}}
    result = compare_observations(before, after)
    assert result["non_interference_passed"] is True


def test_secret_dependent_count_change_is_reported():
    before = {"data": {"resource": {"id": 201, "confidentialDocumentCount": 2}}}
    after = {"data": {"resource": {"id": 201, "confidentialDocumentCount": 5}}}
    result = compare_observations(before, after)
    assert result["non_interference_passed"] is False


def test_normalization_sorts_mapping_keys_but_preserves_values():
    assert normalize_response({"b": 2, "a": 1}) == {"a": 1, "b": 2}
