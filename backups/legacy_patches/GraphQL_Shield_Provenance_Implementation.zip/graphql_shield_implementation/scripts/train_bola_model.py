"""Train XGBoost from labelled runtime telemetry grouped by query template.

Input CSV columns: all FEATURE_COLUMNS, query_template_id, label.
label: 0=legitimate request, 1=suspicious BOLA attempt.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import json

import pandas as pd
from sklearn.metrics import (
    accuracy_score,
    average_precision_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import GroupShuffleSplit
from xgboost import XGBClassifier

from app.security.request_features import FEATURE_COLUMNS


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/bola_training.csv")
    parser.add_argument("--output", default="models/bola_xgboost.json")
    args = parser.parse_args()

    csv_path = Path(args.input)
    if not csv_path.is_file():
        raise SystemExit(
            f"Training data not found: {csv_path}. Collect labelled traces first; "
            "do not train on invented or duplicated rows."
        )

    data = pd.read_csv(csv_path)
    required = set(FEATURE_COLUMNS) | {"query_template_id", "label"}
    missing = sorted(required - set(data.columns))
    if missing:
        raise SystemExit(f"Missing CSV columns: {missing}")
    if data.empty:
        raise SystemExit("Training CSV has no rows.")
    if data["label"].isna().any() or not set(data["label"].unique()).issubset({0, 1}):
        raise SystemExit("label must contain only 0 (benign) or 1 (suspicious BOLA attempt).")
    if data["query_template_id"].nunique() < 4:
        raise SystemExit("Use at least four distinct query_template_id groups for a meaningful grouped split.")

    X = data[FEATURE_COLUMNS].apply(pd.to_numeric, errors="coerce").fillna(0)
    y = data["label"].astype(int)
    groups = data["query_template_id"].astype(str)

    # Select a grouped split containing both classes in train and test. This avoids
    # near-identical request rows from the same template crossing the split.
    selected = None
    splitter = GroupShuffleSplit(n_splits=100, test_size=0.25, random_state=42)
    for train_idx, test_idx in splitter.split(X, y, groups):
        if y.iloc[train_idx].nunique() == 2 and y.iloc[test_idx].nunique() == 2:
            selected = (train_idx, test_idx)
            break
    if selected is None:
        raise SystemExit(
            "Could not form a grouped train/test split containing both labels. "
            "Add more diverse query templates and attack scenarios."
        )

    train_idx, test_idx = selected
    model = XGBClassifier(
        n_estimators=300,
        max_depth=4,
        learning_rate=0.05,
        subsample=0.85,
        colsample_bytree=0.85,
        objective="binary:logistic",
        eval_metric="logloss",
        random_state=42,
        n_jobs=4,
    )
    model.fit(X.iloc[train_idx], y.iloc[train_idx])
    predicted = model.predict(X.iloc[test_idx]).astype(int)
    probabilities = model.predict_proba(X.iloc[test_idx])[:, 1]

    report = {
        "train_rows": len(train_idx),
        "test_rows": len(test_idx),
        "train_query_templates": int(groups.iloc[train_idx].nunique()),
        "test_query_templates": int(groups.iloc[test_idx].nunique()),
        "accuracy": float(accuracy_score(y.iloc[test_idx], predicted)),
        "precision": float(precision_score(y.iloc[test_idx], predicted, zero_division=0)),
        "recall": float(recall_score(y.iloc[test_idx], predicted, zero_division=0)),
        "f1": float(f1_score(y.iloc[test_idx], predicted, zero_division=0)),
        "pr_auc": float(average_precision_score(y.iloc[test_idx], probabilities)),
        "roc_auc": float(roc_auc_score(y.iloc[test_idx], probabilities)),
        "confusion_matrix": confusion_matrix(y.iloc[test_idx], predicted).tolist(),
        "classification_report": classification_report(y.iloc[test_idx], predicted, zero_division=0, output_dict=True),
        "features": FEATURE_COLUMNS,
        "label_definition": {"0": "legitimate request", "1": "suspicious BOLA attempt"},
        "split_method": "GroupShuffleSplit by query_template_id",
    }

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    model.save_model(str(output_path))
    metrics_path = output_path.with_suffix(".metrics.json")
    metrics_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(json.dumps(report, indent=2))
    print(f"Saved model: {output_path}")
    print(f"Saved metrics: {metrics_path}")


if __name__ == "__main__":
    main()
