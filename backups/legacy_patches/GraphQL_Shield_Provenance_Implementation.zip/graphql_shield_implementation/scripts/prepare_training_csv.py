"""Convert JSONL telemetry into a CSV for manual, independent labelling."""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from app.security.request_features import FEATURE_COLUMNS


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default="data/bola_telemetry.jsonl")
    parser.add_argument("--output", default="data/bola_training.csv")
    args = parser.parse_args()

    source = Path(args.input)
    if not source.is_file():
        raise SystemExit(f"Telemetry file not found: {source}. Enable GRAPHQL_SHIELD_TELEMETRY_FILE and exercise the app first.")

    records = []
    with source.open("r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            if not line.strip():
                continue
            try:
                item = json.loads(line)
            except json.JSONDecodeError as exc:
                print(f"Skipping malformed JSONL line {line_number}: {exc}")
                continue
            if "query_template_id" not in item:
                continue
            row = {"query_template_id": item["query_template_id"]}
            row.update({column: item.get(column, 0) for column in FEATURE_COLUMNS})
            # Leave labels blank; assign them only from independent known-truth
            # scenarios, never from the model_prediction/model_risk_score fields.
            row["label"] = ""
            records.append(row)

    if not records:
        raise SystemExit("No valid telemetry records were found.")
    frame = pd.DataFrame(records, columns=["query_template_id", *FEATURE_COLUMNS, "label"])
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(output, index=False)
    print(f"Exported {len(frame)} rows to {output}")
    print("Next: label each row from a controlled test's ground truth (0=legitimate, 1=suspicious BOLA attempt).")


if __name__ == "__main__":
    main()
