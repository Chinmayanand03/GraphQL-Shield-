# GraphQL-Shield ownership-provenance implementation patch

This bundle is based on source files fetched from the public `master` branch of `Chinmayanand03/GraphQL-Shield-` on 2026-10-15. It was not pushed to GitHub and is not installed in your local Windows working tree. Back up your project before merging.

## 1. Copy the new modules

Copy these files into the same relative paths in your local repository:

- `app/security/provenance.py`
- `app/security/runtime_object_guard.py`
- `app/security/request_features.py`
- `app/security/ml_risk_detector.py`
- `app/security/telemetry.py`
- `app/security/non_interference.py`
- `scripts/train_bola_model.py`
- `tests/test_non_interference.py`

Replace `app/graphql/schema.py` with the `app/graphql/schema.py` version in this bundle. It registers the extension class on the schema. The extension explicitly skips `/graphql-insecure` so the intentionally vulnerable benchmark endpoint is preserved.

## 2. Integrate the existing preflight gateway

The current `app/security/enforcement.py` must continue doing its existing request-level authorization. Merge the snippets in `enforcement_change.py.txt` into it; do not replace the file.

These small changes:
- store the query text and variables for post-execution feature extraction,
- place preflight decisions in the request-local evidence ledger, and
- score explicit BOLA attempts that get blocked before GraphQL execution.

The ML result is informational only. It must never override `PolicyEngine`.

## 3. What the runtime extension covers

- Concrete `ResourceType` objects returned by resolvers on `/graphql`.
- Direct, nested, and list object results that pass through the Strawberry schema extension.
- Canonical owner lookup via the existing `get_object_owner("Resource", object_id)` adapter.
- Per-object evaluation using the existing `PolicyEngine` and admin role.
- Filtering unauthorized list elements before GraphQL resolves their child fields; replacing unauthorized single objects with `None`.
- Request-scoped source-row/relationship provenance, decision evidence, audit logging, and output-path consistency checking.

The extension covers the current `ResourceType` type and `objects` SQLite table. It does not automatically track secrets copied into arbitrary scalars, aggregates, external calls, background tasks, subscriptions, or custom resolver return types. Those must be instrumented separately before claiming broad response authorization closure.

## 4. Run tests first

From PowerShell, in the project root:

```powershell
python -m pytest tests/test_non_interference.py -q
python -m pytest -q
```

Then run the existing nested-BOLA regression test with the resolver-level child filter temporarily bypassed in an isolated test. Confirm that the runtime guard still filters a foreign-owned child from `/graphql`, restore the original filter, and run the full suite again.

This bundle was created without direct access to your local Windows checkout. It has not been executed against your full project and is not yet a validated patch.

## 5. ML training

Install optional packages:

```powershell
pip install -r requirements-ml.txt
```

To collect feature rows while exercising the protected API, set an output path before starting Uvicorn (in the same PowerShell window):

```powershell
$env:GRAPHQL_SHIELD_TELEMETRY_FILE = "data\bola_telemetry.jsonl"
uvicorn app.main:app --reload
```

The logger writes structural/numeric features and a query-template hash only. It does not write the raw query, response body, or principal ID. Then export the recorded rows:

```powershell
python scripts/prepare_training_csv.py --input data/bola_telemetry.jsonl --output data/bola_training.csv
```

Open `data/bola_training.csv` and fill `label` from independently verified test ground truth: `0=legitimate request`, `1=suspicious BOLA attempt`. Do not derive labels from the model prediction or score columns. Collect diverse templates and labelled attack scenarios before training.

Train and evaluate using a grouped split:

```powershell
python scripts/train_bola_model.py --input data/bola_training.csv --output models/bola_xgboost.json
```

The runtime performs inference only when a trained model exists. Until then, state is reported as `UNTRAINED`; no synthetic prediction is shown. `request.state.graphql_shield_security.ml_risk` holds the latest result for dashboard/audit integration.

## 6. Non-interference validation

`compare_observations(before, after)` compares normalized JSON GraphQL responses. Build paired database fixtures where only another user's protected data changes, retain the requesting user's identity and authorized/public data, and compare fields that the policy says should remain independent of that secret. A changed response is a candidate counterexample; a test author must investigate whether the changed field was actually supposed to be hidden. Finite passing tests are not a mathematical proof of non-interference.
