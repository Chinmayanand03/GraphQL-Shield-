# GraphQL Shield: Final Demo Persona/Login Migration

This is a targeted local-demo patch to apply the requested human-readable login names and exact IDs, and to show them on the dashboard.

## Final personas

| ID | Display name | Login username | Role | Password note |
|---:|---|---|---|---|
| 104 | Agnihotram Chinmayanand | `chinmay` | `ADMIN` | Existing Charlie password is preserved (`charlie123` in the original seed setup) |
| 101 | B.V. Balanilavan | `bala` | `USER` | Existing Alice password is preserved (`alice123` in the original seed setup) |
| 102 | Kapilesh N | `kapilesh` | `USER` | Existing Bob password is preserved (`bob123` in the original seed setup) |
| 103 | Sakthivel B | `sakthivel` | `USER` | New account gets the local demo password `sakthivel123`; change it before any non-local use |

The migration keeps the existing object IDs, moves user-ownership references for the current admin from ID 103 to ID 104, and moves any existing Sakthivel references to ID 103 if a previous persona patch already created Sakthivel under another ID. It also remaps declared foreign keys to `users.id` (including audit user IDs and object owner IDs) within a transaction.

## Backward compatibility

The application login route accepts new usernames and old test/benchmark aliases:

- `bala` and legacy `alice`
- `kapilesh` and legacy `bob`
- `chinmay` and legacy `charlie`
- `sakthivel`

This allows existing tests/scripts that still log in as `alice`, `bob`, or `charlie` to work on their legacy test databases. Existing original account password hashes are preserved. The local development project's simple login scheme is `hash_<password>`; do not treat it as a production password-storage design.

## Install

1. Stop the local app server with `Ctrl+C` if it is running.
2. Save this ZIP in your project root, e.g. `C:\Users\CHINMAYANAND\Downloads\GraphQL-Shield`.
3. Extract the ZIP into the project root. It should place `apply_demo_personas.py` and this README at the root. Do not extract over unrelated files.
4. From a PowerShell terminal in the project root run:

   ```powershell
   python .\apply_demo_personas.py
   ```

5. Check the printed final IDs/names, then run:

   ```powershell
   python -m pytest -q
   ```

6. Restart the app and refresh `http://127.0.0.1:8000/dashboard` with `Ctrl+F5`.

## Backups and safety

Before changes, the script creates a timestamped folder under `backups/` with copies of `app/main.py`, `app/static/dashboard.html`, `app/database.py`, optional `app/seed.py`, and a consistent SQLite database backup. It checks the expected persona accounts and refuses to proceed if an unrelated user occupies IDs 101–104 or if both a canonical and legacy username exist as separate rows for the same persona.

The database update is transactional. Before commit, it runs `PRAGMA foreign_key_check`; a failure causes rollback. The script does not print password hashes or tokens.

**Important:** `app/seed.py` is deliberately not modified because tests use it to generate the legacy `alice`/`bob`/`charlie` test fixture; the login aliases preserve test compatibility. If you deliberately reset the main database using the seed script, it restores the original seeded names and you will need to rerun this one-time migration for the local demo database.

Keep `.env` and any real secrets out of source control. This four-account setup is for local demonstration only, not production deployment.
