# Relationship BOLA Regression Fix

This follow-up patch addresses two findings from `research_hardening_verification.json`:

1. The protected `/graphql` resolver returned child object `102` from `resource.children` even though Alice (user `101`) does not own it. The parent folder `201` is Alice-owned, but parent ownership must not confer access to every child.
2. The dynamic verifier used `PROTECTION_FAILED_CONFIRMED` whenever both endpoints returned a target, including 19 legitimate control requests. The verifier now uses the independent `AttackCase.expected_authorized` value when assigning verdicts.

## Apply in PowerShell

1. Download this ZIP and extract its contents into your project root **without extracting the `payload` folder over the application files**. The archive intentionally stores replacement source files under `payload/` so the installer can back up existing files before replacing them.
2. From the project root run:

   ```powershell
   .\apply_relationship_fix.ps1
   ```

3. Run the tests:

   ```powershell
   python -m pytest -q
   ```

4. Run the same smoke benchmark again:

   ```powershell
   python scripts/run_research_benchmark.py --count 100 --seed 20261011 --output-dir results/research_hardening_smoke_after_fix
   ```

5. Inspect `results/research_hardening_smoke_after_fix/research_hardening_verification.json` and the matching `_raw.csv`.

## Expected behavior

For Alice's query:

```graphql
query RelationshipBOLA {
  resource(id: 201) {
    id
    children { id name ownerId parentId }
  }
}
```

- `/graphql-insecure` remains the intentionally vulnerable comparison endpoint and returns child `102` plus children `202` and `203`.
- `/graphql` should omit foreign-owned child `102` while keeping Alice-owned children `202` and `203`.
- An administrator should retain access to all children.
- When a BOLA target is absent from the protected response, the verdict is `PROTECTION_VERIFIED_BY_TARGET_ABSENCE`, not a generic inconclusive/failed verdict.
- If an expected-authorized target remains visible on both endpoints, the verdict is `LEGITIMATE_ACCESS_PRESERVED`, not `PROTECTION_FAILED_CONFIRMED`.

The installer backs up `app/graphql/types.py`, `app/security/dynamic_verifier.py`, and `app/security/enforcement.py` under `backups/relationship_bola_fix_pre_patch/` before modifying them.

The install script adds `request.state.current_user = current_user` to the existing one-line `bola_enforcement_middleware` function. If the function signature differs from the expected shape, it stops rather than silently changing code.

## Scope and validation

This is a targeted source patch. It assumes the project's existing authorization policy grants ordinary users access to resources they own and administrators access to all resources. It deliberately filters only the `children` relation on `/graphql`; the `/graphql-insecure` endpoint remains unchanged for benchmark comparison.
