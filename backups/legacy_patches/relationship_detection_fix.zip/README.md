# GraphQL Shield: Relationship-Aware Detector Fix

This is a targeted patch to improve **analysis-time** detection of BOLA through implicit object-valued relationships, such as `resource(id: $parentId) { children { id ownerId } }`.

It does not replace the GraphQL resolver authorization fix. Runtime authorization remains the control that prevents disclosure; this patch improves the benchmark detector and corrects the relationship benchmark's legitimate-control fixture.

## What this patch changes

- Adds `app/benchmarks/relationship_detector.py`, which parses implicit nested relationship paths, resolves children from the supplied object/ownership catalog, and flags a query if a known child owner differs from the authenticated principal. Unknown ownership is reported as inconclusive rather than asserted as a confirmed BOLA.
- Updates `app/benchmarks/runner.py` to include the relationship detector in `authorization_aware_candidate` and record relationship evidence/status in raw benchmark rows.
- Updates `app/benchmarks/dataset.py` to dataset version 1.2. Relationship BOLA cases traverse Alice's folder 201, which contains Bob-owned child 102 in the temporary benchmark database. Legitimate controls traverse Bob's folder 204, whose children 205 and 206 are Bob-owned. This avoids labelling a query as legitimate when the same parent response would also expose a foreign child.
- Updates the existing integration-test assertions and adds five relationship-detector tests.
- Installs Bob's folder and children only in the benchmark's temporary evaluation database. It does not alter `app/seed.py` or the configured development database.

## Apply safely on Windows / PowerShell

1. Download `relationship_detection_fix.zip` and save it in the project root, for example `C:\Users\CHINMAYANAND\Downloads\GraphQL-Shield`.
2. Extract the ZIP into that project root. Make sure it extracts `apply_relationship_detection_fix.ps1`, `README.md`, and the `payload` folder. Do not manually copy files one-by-one.
3. From the project root, run:

   ```powershell
   .\apply_relationship_detection_fix.ps1
   ```

   The script checks all source files and required project prerequisites before copying anything. It backs up the replaced files to a timestamped directory under `backups/relationship_detection_pre_patch_...`.
4. Run the full suite:

   ```powershell
   python -m pytest -q
   ```

5. If the full suite passes, run a smoke benchmark into a **new** folder so existing results remain unchanged:

   ```powershell
   python scripts/run_research_benchmark.py --count 100 --seed 20261011 --output-dir results/relationship_detection_smoke
   ```

6. Open `results/relationship_detection_smoke/research_benchmark_report.json` and inspect `detection_metrics.by_scenario_group.implicit_relationship_access` and `implicit_relationship_bola_only`. Also inspect the raw CSV columns `authorization_aware_candidate`, `relationship_bola_prediction`, `relationship_analysis_status`, and `relationship_unauthorized_child_ids`.

## Tests performed before packaging

- Python syntax compilation passed for all changed Python files.
- Five focused tests for relationship detection passed in an isolated validation harness.
- Dataset generation was exercised for 300 cases: relationship BOLA cases use parent 201/target 102/principal 101; legitimate relationship cases use parent 204/target 205 or 206/principal 102.

The complete project test suite and end-to-end benchmark have not been run in your Antigravity environment. Treat the locally executed `pytest` and smoke benchmark as required verification before accepting the patch.

## What success should look like

- `relationship_bola` detections should be `True` because parent 201 contains foreign-owned child 102.
- `relationship_legitimate` detections should be `False` because parent 204 contains only Bob-owned children 205/206.
- Administrator relationship probes should not be flagged by this detector.
- Direct/nested detector behavior and the runtime resolver behavior should remain covered by the existing suite.

A better synthetic benchmark result does not prove generalization to arbitrary production GraphQL schemas. The detector relies on a supplied ownership/relationship catalog and should be evaluated against independent datasets before making broad claims.
